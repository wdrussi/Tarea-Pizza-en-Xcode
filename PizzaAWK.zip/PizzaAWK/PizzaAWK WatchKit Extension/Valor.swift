//
//  Valor.swift
//  PizzaAWK
//
//  Created by Nicolas Russi on 2/03/21.
//  Copyright © 2021 Nicolas Russi. All rights reserved.
//

import WatchKit

class Valor: NSObject {
    var tamaño:String? = nil
    var masa:String? = nil
    var queso:String? = nil
    var ingredientes: [String] = []
}
