//
//  TipoQueso.swift
//  PizzaAWK
//
//  Created by Nicolas Russi on 2/03/21.
//  Copyright © 2021 Nicolas Russi. All rights reserved.
//

import WatchKit
import Foundation


class TipoQueso: WKInterfaceController {

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        self.setTitle("Clase De Queso")
        valorSeleccionado = context as! Valor
        // Configure interface objects here.
    }

    let mozarela:String = "Mozarela"
    let cheddar:String = "Cheddar"
    let parmesano:String = "Parmesano"
    let sinQueso:String = "Sin Queso"
    var valorSeleccionado:Valor = Valor()
    
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func SeleMozarela() {
        seleccion(mozarela)
    }
    @IBAction func SeleCheddar() {
        seleccion(cheddar)
    }
    @IBAction func SeleParmesano() {
        seleccion(parmesano)
    }
    @IBAction func SeleSinQueso() {
        seleccion(sinQueso)
    }

    func seleccion(_ opcion:String) {
        valorSeleccionado.queso = opcion
        pushController(withName: "idIngredientes", context: valorSeleccionado)
        print(opcion)
    }
    
    
}
