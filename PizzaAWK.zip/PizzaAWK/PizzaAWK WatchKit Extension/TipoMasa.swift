
//
//  TipoMasa.swift
//  PizzaAWK
//
//  Created by Nicolas Russi on 2/03/21.
//  Copyright © 2021 Nicolas Russi. All rights reserved.
//

import WatchKit
import Foundation


class TipoMasa: WKInterfaceController {

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        self.setTitle("Tipo De Masa")
        // Configure interface objects here.
    }

    let delgada:String = "Delgada"
    let crujiente:String = "Crujiente"
    let gruesa:String = "Gruesa"
    var valorSeleccionado:Valor = Valor()
    
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    @IBAction func SeleDelgada() {
        seleccion(delgada)
    }
    @IBAction func SeleCrujiente() {
        seleccion(crujiente)
    }
    @IBAction func SeleGruesa() {
        seleccion(gruesa)
    }

    
    func seleccion(_ opcion:String) {
        valorSeleccionado.masa = opcion
        pushController(withName: "tipoQueso", context: valorSeleccionado)
        print(opcion)
    }
    

}
