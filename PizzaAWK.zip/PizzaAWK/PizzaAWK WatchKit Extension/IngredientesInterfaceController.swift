//
//  IngredientesInterfaceController.swift
//  PizzaAWK
//
//  Created by Nicolas Russi on 2/03/21.
//  Copyright © 2021 Nicolas Russi. All rights reserved.
//

import WatchKit
import Foundation


class IngredientesInterfaceController: WKInterfaceController {

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        self.setTitle("Ingredientes")
        valorSeleccionado = context as! Valor
    }   // Configure interface objects here.
        
        var jamon:Bool = false
        var pepperoni:Bool = false
        var pavo:Bool = false
        var salchicha:Bool = false
        var aceituna:Bool = false
        var cebolla:Bool = false
        var pimineta:Bool = false
        var piña:Bool = false
        var pollo:Bool = false
        var champiñion:Bool = false
        var valorSeleccionado:Valor = Valor()

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func Continuar() {
        valorSeleccionado.ingredientes.removeAll()
        if (jamon) {
            valorSeleccionado.ingredientes.append("Jamon")
        }
        if (pepperoni) {
            valorSeleccionado.ingredientes.append("Pepperoni")
        }
        if (pavo) {
            valorSeleccionado.ingredientes.append("Pavo")
        }
        if (salchicha) {
            valorSeleccionado.ingredientes.append("Salchicha")
        }
        if (aceituna) {
            valorSeleccionado.ingredientes.append("Aceituna")
        }
        if (cebolla) {
            valorSeleccionado.ingredientes.append("Cebolla")
        }
        if (pimineta) {
            valorSeleccionado.ingredientes.append("Pimienta")
        }
        if (piña) {
            valorSeleccionado.ingredientes.append("Piña")
        }
        if (pollo) {
            valorSeleccionado.ingredientes.append("Pollo")
        }
        if (champiñion) {
            valorSeleccionado.ingredientes.append("Champiñion")
        }
        if (valorSeleccionado.ingredientes.count>=1&&valorSeleccionado.ingredientes.count<=5){
            pushController(withName: "Confirmacion", context: valorSeleccionado)
            print(valorSeleccionado.ingredientes)
        }
    }
    @IBAction func SeleJamon(_ value: Bool) {
        jamon = value
    }
    @IBAction func SelePepperoni(_ value: Bool) {
        pepperoni = value
    }
    @IBAction func SelePavo(_ value: Bool) {
        pavo = value
    }
    @IBAction func SeleSalchicha(_ value: Bool) {
        salchicha = value
    }
    @IBAction func SeleAceituna(_ value: Bool) {
        aceituna = value
    }
    @IBAction func SeleCebolla(_ value: Bool) {
        cebolla = value
    }
    @IBAction func SelePimienta(_ value: Bool) {
        pimineta = value
    }
    @IBAction func SelePiña(_ value: Bool) {
        piña = value
    }
    @IBAction func SelePollo(_ value: Bool) {
        pollo = value
    }
    @IBAction func SeleChampiñion(_ value: Bool) {
        champiñion = value
    }
}
