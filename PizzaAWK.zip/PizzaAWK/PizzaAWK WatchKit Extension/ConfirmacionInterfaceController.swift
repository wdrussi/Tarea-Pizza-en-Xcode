//
//  ConfirmacionInterfaceController.swift
//  PizzaAWK
//
//  Created by Nicolas Russi on 2/03/21.
//  Copyright © 2021 Nicolas Russi. All rights reserved.
//

import WatchKit
import Foundation


class ConfirmacionInterfaceController: WKInterfaceController {
    
    @IBOutlet var tamaño: WKInterfaceLabel!
    @IBOutlet var masa: WKInterfaceLabel!
    @IBOutlet var queso: WKInterfaceLabel!
    @IBOutlet var ingredientes: WKInterfaceLabel!
    @IBOutlet var cocina: WKInterfaceLabel!
    @IBOutlet var ConfirmarButton: WKInterfaceButton!
    @IBOutlet var CambiarPedidoButton: WKInterfaceButton!
    var valorSeleccionado: Valor = Valor()
    

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        self.setTitle("Orden Solicitada")
        cocina.setHidden(true)
        valorSeleccionado = context as! Valor
        // Configure interface objects here.
    }

    override func willActivate() {
        super.willActivate()
        tamaño.setText(valorSeleccionado.tamaño)
        masa.setText(valorSeleccionado.masa)
        queso.setText(valorSeleccionado.queso)
        var ingredientesSalida:String = " "
        var i = 0
        while i < valorSeleccionado.ingredientes.count - 1 {
            ingredientesSalida += valorSeleccionado.ingredientes[i] + ", "
            i += 1
        }
        ingredientesSalida += valorSeleccionado.ingredientes[i]
        ingredientes.setText(String(ingredientesSalida))
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func confirmar() {
        cocina.setHidden(false)
        ConfirmarButton.setHidden(true)
        CambiarPedidoButton.setHidden(true)
        
    }
    
    
}
